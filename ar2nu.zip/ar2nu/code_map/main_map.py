import os
import json
from pathlib import Path
import numpy as np
from tqdm import tqdm
from typing import Dict, List, Optional, Tuple

def process_map_expansions(
    reference_map_dir: str = r"C:\Users\mitvi\Downloads\argov2_00000\map",
    output_dir: str = r"C:\Users\mitvi\Downloads\argov2_00000\output\map",
    scene_numbers: List[int] = [1, 2, 3, 4, 5]
) -> None:
    """
    Process map data to create map expansion and prediction files.
    
    Args:
        reference_map_dir: Directory containing reference map data
        output_dir: Directory to save processed map data
        scene_numbers: List of scene numbers to process
    """
    # Create output directories
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Process each scene
    for scene_num in tqdm(scene_numbers, desc="Processing map expansions"):
        # Create scene-specific output directory
        scene_output_dir = output_path / f"scene_{scene_num}"
        scene_output_dir.mkdir(exist_ok=True)
        
        # Process map data for this scene
        process_single_scene_maps(
            scene_num=scene_num,
            reference_map_dir=reference_map_dir,
            output_dir=scene_output_dir
        )

def process_single_scene_maps(
    scene_num: int,
    reference_map_dir: str,
    output_dir: Path
) -> None:
    """Process map data for a single scene."""
    # Load reference map data
    reference_map_path = Path(reference_map_dir) / f"scene_{scene_num}_map.json"
    if not reference_map_path.exists():
        print(f"⚠ Reference map not found: {reference_map_path}")
        return
    
    with open(reference_map_path, 'r') as f:
        reference_data = json.load(f)
    
    # Process map expansion data
    expansion_data = create_map_expansion(reference_data, scene_num)
    with open(output_dir / "map_expansion.json", 'w') as f:
        json.dump(expansion_data, f, indent=2)
    
    # Process prediction data
    prediction_data = create_prediction_data(reference_data, scene_num)
    with open(output_dir / "prediction.json", 'w') as f:
        json.dump(prediction_data, f, indent=2)

def create_map_expansion(reference_data: dict, scene_num: int) -> dict:
    """Create map expansion data from reference data."""
    return {
        "version": "1.0",
        "scene_id": f"scene_{scene_num}",
        "map_expansion": {
            "version": "1.0",
            "city": "pittsburgh",
            "scene_id": f"scene_{scene_num}",
            # Add more map expansion data here based on reference_data
        }
    }

def create_prediction_data(reference_data: dict, scene_num: int) -> dict:
    """Create prediction data from reference data."""
    return {
        "version": "1.0",
        "scene_id": f"scene_{scene_num}",
        "predictions": [
            {
                "instance_id": f"pred_{scene_num}_{i}",
                "prediction": [0.0, 0.0, 0.0],  # Example prediction
                "confidence": 0.9,  # Example confidence
                # Add more prediction data here
            } for i in range(10)  # Example: 10 predictions per scene
        ]
    }

if __name__ == "__main__":
    process_map_expansions()