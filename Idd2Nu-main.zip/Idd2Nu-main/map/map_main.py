"""
Map Main Script for Argoverse 2 Data Processing

This script:
1. Loads Argoverse 2 map data
2. Syncs tokens with annotation files
3. Generates expansion data (polygon format)
4. Generates prediction data (instance_token_sample_token pairs)
"""

import json
import os
import uuid
from collections import defaultdict
from pathlib import Path


class TokenManager:
    """Manages token synchronization between maps and annotations"""
    
    def __init__(self, annotation_tokens_path=None):
        self.tokens = {}
        if annotation_tokens_path and os.path.exists(annotation_tokens_path):
            with open(annotation_tokens_path, 'r') as f:
                self.tokens = json.load(f)
    
    def get(self, name):
        """Get or create a token for a given name"""
        if name not in self.tokens:
            # Use UUID format with dashes to match nuScenes format
            self.tokens[name] = str(uuid.uuid4())
        return self.tokens[name]
    
    def save(self, path):
        """Save tokens to file"""
        with open(path, 'w') as f:
            json.dump(self.tokens, f, indent=4)


def extract_polygon_from_boundary(boundary_points):
    """Extract polygon nodes from boundary points"""
    if not boundary_points:
        return []
    # Convert {x, y, z} points to node tokens
    nodes = []
    for point in boundary_points:
        # Create a unique identifier for this node based on coordinates
        node_id = f"node_{point['x']:.2f}_{point['y']:.2f}_{point['z']:.2f}"
        nodes.append(node_id)
    return nodes


def process_lane_segment(lane_id, lane_data, tokens):
    """Process a lane segment into polygon format matching nuScenes structure"""
    polygons = []
    
    # Create polygon from left and right boundaries
    left_boundary = lane_data.get('left_lane_boundary', [])
    right_boundary = lane_data.get('right_lane_boundary', [])
    
    if left_boundary and right_boundary:
        # Combine boundaries to form a closed polygon
        # Start with left boundary, then reverse right boundary
        exterior_points = left_boundary + list(reversed(right_boundary))
        
        if len(exterior_points) >= 3:  # Minimum 3 points for a polygon
            polygon_token = tokens.get(f"polygon_lane_{lane_id}")
            node_tokens = []
            
            for point in exterior_points:
                node_id = f"node_lane_{lane_id}_{point['x']:.2f}_{point['y']:.2f}"
                node_token = tokens.get(node_id)
                node_tokens.append(node_token)
            
            # nuScenes format: holes is array of objects with node_tokens
            # For now, we don't have hole data from Argoverse, so use empty array
            polygons.append({
                "token": polygon_token,
                "exterior_node_tokens": node_tokens,
                "holes": []  # Empty array, or array of {"node_tokens": [...]} if holes exist
            })
    
    return polygons


def process_drivable_area(area_id, area_data, tokens):
    """Process a drivable area into polygon format matching nuScenes structure"""
    polygons = []
    
    area_boundary = area_data.get('area_boundary', [])
    
    if len(area_boundary) >= 3:  # Minimum 3 points for a polygon
        polygon_token = tokens.get(f"polygon_drivable_{area_id}")
        node_tokens = []
        
        for point in area_boundary:
            node_id = f"node_drivable_{area_id}_{point['x']:.2f}_{point['y']:.2f}"
            node_token = tokens.get(node_id)
            node_tokens.append(node_token)
        
        # nuScenes format: holes is array of objects with node_tokens
        polygons.append({
            "token": polygon_token,
            "exterior_node_tokens": node_tokens,
            "holes": []  # Empty array, or array of {"node_tokens": [...]} if holes exist
        })
    
    return polygons


def process_pedestrian_crossing(crossing_id, crossing_data, tokens):
    """Process a pedestrian crossing into polygon format matching nuScenes structure"""
    polygons = []
    
    # Pedestrian crossings typically have a boundary or polygon
    boundary = crossing_data.get('polygon', crossing_data.get('boundary', []))
    
    if isinstance(boundary, list) and len(boundary) >= 3:
        polygon_token = tokens.get(f"polygon_crossing_{crossing_id}")
        node_tokens = []
        
        for point in boundary:
            if isinstance(point, dict):
                node_id = f"node_crossing_{crossing_id}_{point.get('x', 0):.2f}_{point.get('y', 0):.2f}"
            else:
                # Handle different formats
                node_id = f"node_crossing_{crossing_id}_{hash(str(point))}"
            node_token = tokens.get(node_id)
            node_tokens.append(node_token)
        
        # nuScenes format: holes is array of objects with node_tokens
        polygons.append({
            "token": polygon_token,
            "exterior_node_tokens": node_tokens,
            "holes": []  # Empty array, or array of {"node_tokens": [...]} if holes exist
        })
    
    return polygons


def generate_expansion_data(map_data, tokens, location_name="PIT"):
    """Generate expansion data from map features"""
    all_polygons = []
    
    # Process lane segments
    lane_segments = map_data.get('lane_segments', {})
    print(f"Processing {len(lane_segments)} lane segments...")
    for lane_id, lane_data in lane_segments.items():
        polygons = process_lane_segment(lane_id, lane_data, tokens)
        all_polygons.extend(polygons)
    
    # Process drivable areas
    drivable_areas = map_data.get('drivable_areas', {})
    print(f"Processing {len(drivable_areas)} drivable areas...")
    for area_id, area_data in drivable_areas.items():
        polygons = process_drivable_area(area_id, area_data, tokens)
        all_polygons.extend(polygons)
    
    # Process pedestrian crossings
    pedestrian_crossings = map_data.get('pedestrian_crossings', {})
    print(f"Processing {len(pedestrian_crossings)} pedestrian crossings...")
    for crossing_id, crossing_data in pedestrian_crossings.items():
        polygons = process_pedestrian_crossing(crossing_id, crossing_data, tokens)
        all_polygons.extend(polygons)
    
    expansion_data = {
        "version": "1.3",
        "polygon": all_polygons
    }
    
    print(f"[OK] Generated {len(all_polygons)} polygons for expansion data")
    return expansion_data


def generate_prediction_data(instance_json_path, sample_json_path, sample_annotation_json_path, tokens):
    """Generate prediction data by combining instance and sample tokens"""
    # Load instance, sample, and sample_annotation data
    with open(instance_json_path, 'r') as f:
        instances = json.load(f)
    
    with open(sample_json_path, 'r') as f:
        samples = json.load(f)
    
    with open(sample_annotation_json_path, 'r') as f:
        sample_annotations = json.load(f)
    
    # Create mapping from sample tokens to scene tokens
    sample_to_scene = {}
    for sample in samples:
        sample_to_scene[sample['token']] = sample.get('scene_token', '')
    
    # Create mapping from annotation tokens to instance tokens
    annotation_to_instance = {}
    for ann in sample_annotations:
        ann_token = ann.get('token', '')
        instance_token = ann.get('instance_token', '')
        sample_token = ann.get('sample_token', '')
        if ann_token and instance_token and sample_token:
            annotation_to_instance[ann_token] = {
                'instance_token': instance_token,
                'sample_token': sample_token
            }
    
    # Group instance-sample pairs by scene
    scene_pairs = defaultdict(set)
    
    # For each annotation, create instance-sample pair
    for ann in sample_annotations:
        instance_token = ann.get('instance_token', '')
        sample_token = ann.get('sample_token', '')
        
        if instance_token and sample_token:
            scene_token = sample_to_scene.get(sample_token, '')
            if scene_token:
                pair_token = f"{instance_token}_{sample_token}"
                scene_pairs[scene_token].add(pair_token)
    
    # Create prediction scenes
    prediction_scenes = {}
    scene_num = 1
    
    # Sort scenes by token for consistent ordering
    sorted_scenes = sorted(scene_pairs.keys())
    
    for scene_token in sorted_scenes:
        scene_name = f"scene-{scene_num:04d}"
        prediction_scenes[scene_name] = sorted(list(scene_pairs[scene_token]))
        scene_num += 1
    
    print(f"[OK] Generated prediction data with {len(prediction_scenes)} scenes")
    print(f"   Total instance-sample pairs: {sum(len(pairs) for pairs in prediction_scenes.values())}")
    return prediction_scenes


def sync_map_tokens(map_data, annotation_tokens, log_token):
    """Sync map tokens with annotation tokens"""
    # Ensure map token exists and matches log token
    map_token_key = "map_token"
    if map_token_key not in annotation_tokens:
        annotation_tokens[map_token_key] = uuid.uuid4().hex
    
    # Ensure log token matches
    log_token_key = "log"
    if log_token_key in annotation_tokens:
        # Verify the log token matches
        if annotation_tokens[log_token_key] != log_token:
            print(f"[WARNING] Log token mismatch. Using annotation token: {annotation_tokens[log_token_key]}")
    else:
        annotation_tokens[log_token_key] = log_token
    
    return annotation_tokens


def main():
    """Main function to process maps and generate expansion/prediction data"""
    # Paths
    base_dir = Path(__file__).parent.parent
    map_dir = base_dir / "map" / "map"
    output_dir = base_dir / "output"
    annotation_dir = output_dir / "annotation"
    
    # Create output directories
    expansion_dir = output_dir / "expansion"
    expansion_dir.mkdir(parents=True, exist_ok=True)
    
    # Load annotation tokens
    tokens_path = annotation_dir / "tokens_map.json"
    tokens = TokenManager(str(tokens_path))
    
    # Find map files
    map_files = list(map_dir.glob("*.json"))
    print(f"Found {len(map_files)} map files")
    
    # Process each map file
    for map_file in map_files:
        if "log_map_archive" in map_file.name:
            print(f"\n[INFO] Processing map file: {map_file.name}")
            
            # Extract log ID from filename
            log_id = map_file.name.split("___")[0]
            print(f"Log ID: {log_id}")
            
            # Load map data
            with open(map_file, 'r') as f:
                map_data = json.load(f)
            
            # Sync tokens with annotations
            # Get log token from annotation
            log_token = tokens.get("log")
            sync_map_tokens(map_data, tokens.tokens, log_token)
            
            # Generate expansion data
            location_name = "PIT"  # Extract from filename or use default
            expansion_data = generate_expansion_data(map_data, tokens, location_name)
            
            # Save expansion data
            expansion_file = expansion_dir / f"{location_name.lower()}.json"
            with open(expansion_file, 'w') as f:
                json.dump(expansion_data, f, indent=2)
            print(f"[OK] Saved expansion data to {expansion_file}")
    
    # Generate prediction data
    instance_json = annotation_dir / "instance.json"
    sample_json = annotation_dir / "sample.json"
    sample_annotation_json = annotation_dir / "sample_annotation.json"
    
    if instance_json.exists() and sample_json.exists() and sample_annotation_json.exists():
        print(f"\n[INFO] Generating prediction data...")
        prediction_data = generate_prediction_data(
            str(instance_json),
            str(sample_json),
            str(sample_annotation_json),
            tokens
        )
        
        # Save prediction data
        prediction_file = output_dir / "prediction_scenes.json"
        with open(prediction_file, 'w') as f:
            json.dump(prediction_data, f, indent=2)
        print(f"[OK] Saved prediction data to {prediction_file}")
    else:
        print(f"[WARNING] Instance or sample JSON files not found. Skipping prediction data generation.")
    
    # Save updated tokens
    tokens.save(str(tokens_path))
    print(f"[OK] Updated tokens saved to {tokens_path}")
    
    print("\n[SUCCESS] Map processing complete!")


if __name__ == "__main__":
    main()

