# Format Comparison: Generated vs nuScenes Expansion Data

## Current Status

The generated expansion data in `output/expansion/pit.json` matches the nuScenes structure with the following differences:

### ✅ What Matches

1. **Structure**: 
   - `version: "1.3"` ✓
   - `polygon` array ✓
   - Each polygon has `token`, `exterior_node_tokens`, and `holes` ✓

2. **Holes Format**: 
   - Empty arrays `[]` (correct for polygons without holes) ✓
   - Structure supports `[{"node_tokens": [...]}]` format if holes exist ✓

### ⚠️ What's Different

1. **Token Format**:
   - **nuScenes**: UUID with dashes (e.g., `"3fa7d730-293e-43da-adfd-c086dacaf213"`)
   - **Current**: Hex without dashes (e.g., `"d601b140996a46d593b26f8e3a8b2c9a"`)
   - **Reason**: Existing tokens in `tokens_map.json` were created in hex format. New tokens will use UUID format, but existing ones remain hex to maintain references.

2. **Polygon Token Nullability**:
   - **nuScenes**: Can be `null` for some polygons
   - **Current**: Always has a token value
   - **Impact**: Minimal - both formats are valid

## What's Needed to Match nuScenes Exactly

### Option 1: Convert Existing Tokens (Recommended if references can be updated)
- Convert all hex tokens in `tokens_map.json` to UUID format with dashes
- Update all references in annotation files
- **Risk**: May break existing references if other files depend on token values

### Option 2: Keep Current Format (Recommended for stability)
- Hex tokens work functionally the same as UUID tokens
- Structure matches nuScenes exactly
- Only visual format difference
- **Benefit**: No risk of breaking existing references

### Option 3: Hybrid Approach
- Keep existing tokens as-is
- Use UUID format for all new tokens going forward
- Document the difference

## Missing Features (Not in Argoverse 2 Data)

1. **Holes in Polygons**: 
   - nuScenes expansion data can have polygons with interior holes
   - Argoverse 2 map data doesn't provide hole information
   - **Status**: Not available in source data

2. **Node Coordinate Storage**:
   - nuScenes expansion files only store node tokens (not coordinates)
   - Coordinates are stored separately in node files
   - **Status**: Current implementation matches this (only tokens stored)

## Recommendations

1. **For Production Use**: Keep current format - it's functionally equivalent
2. **For Exact nuScenes Compatibility**: Convert tokens to UUID format (requires updating all references)
3. **For Holes Support**: Would need additional processing or different data source

## Code Changes Made

- ✅ Updated `TokenManager.get()` to generate UUID format tokens (for new tokens)
- ✅ Verified structure matches nuScenes format
- ✅ Holes structure supports nuScenes format (empty arrays or objects with `node_tokens`)
- ✅ Version set to "1.3" to match nuScenes

## Next Steps (if exact format needed)

1. Create token conversion script to convert hex → UUID format
2. Update all annotation files with new token references
3. Re-run map_main.py to regenerate with UUID tokens

