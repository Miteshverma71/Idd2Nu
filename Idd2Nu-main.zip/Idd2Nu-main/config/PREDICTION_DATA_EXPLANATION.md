# Prediction Data Generation from nuScenes Mini Dataset

## Overview

The prediction data (`prediction_scenes.json`) is an **expansion** of the nuScenes mini dataset that extends the original dataset for trajectory prediction tasks. It combines data from the nuScenes mini dataset with map expansion information.

## Data Structure

### 1. Prediction Scenes (`prediction_scenes.json`)

**Structure:**
- **Format**: JSON dictionary
- **Keys**: Scene names (e.g., `"scene-0001"`, `"scene-0002"`, etc.)
- **Values**: Lists of token pairs in format `"instance_token_sample_token"`

**Example:**
```json
{
  "scene-0001": [
    "076e76a589dd4f40adce27b3f3377f58_14d5adfe50bb4445bc3aa5fe607691a8",
    "076e76a589dd4f40adce27b3f3377f58_15d5adfe50bb4445bc3aa5fe607691a9",
    ...
  ],
  "scene-0002": [...]
}
```

**Key Statistics:**
- **833 scenes** in prediction data (vs. **10 scenes** in nuScenes mini)
- Each entry is a combination of:
  - `instance_token`: References an object instance from `instance.json`
  - `sample_token`: References a sample timestamp from `sample.json`

### 2. Map Expansion Files (`expansion/`)

**Location**: `nu_scene/expansion/`

**Files:**
- `boston-seaport.json` (6,504 polygons)
- `singapore-hollandvillage.json` (2,739 polygons)
- `singapore-onenorth.json` (4,886 polygons)
- `singapore-queenstown.json` (3,570 polygons)

**Total: 17,699 polygons** across all locations

**Structure:**
```json
{
  "version": "1.3",
  "polygon": [
    {
      "token": "polygon_token",
      "exterior_node_tokens": ["node1", "node2", ...],
      "holes": []
    },
    ...
  ]
}
```

**Purpose**: Contains expanded map polygon data with exterior nodes that provide additional spatial context beyond the base nuScenes mini dataset.

**For detailed information on how expansion data is generated, see [EXPANSION_DATA_EXPLANATION.md](EXPANSION_DATA_EXPLANATION.md)**

## How Prediction Data is Generated

### Process Flow:

1. **Base Data Extraction**:
   - Start with nuScenes mini dataset (`v1.0-mini/`)
   - Extract scenes, samples, instances, and annotations

2. **Scene Expansion**:
   - Expand from 10 mini scenes to 833 prediction scenes
   - Each scene contains multiple instance-sample pairs

3. **Token Combination**:
   - For each scene, combine:
     - `instance_token` (from `instance.json`)
     - `sample_token` (from `sample.json`)
   - Format: `"{instance_token}_{sample_token}"`

4. **Map Integration**:
   - Integrate map expansion data from `expansion/` files
   - Map polygons provide spatial context for trajectory prediction

### Data Relationships:

```
nuScenes Mini Dataset
├── scene.json (10 scenes)
├── sample.json (sample timestamps)
├── instance.json (object instances)
├── sample_annotation.json (annotations)
└── map.json (base map data)

    ↓ EXPANSION PROCESS ↓

Prediction Data
├── prediction_scenes.json (833 scenes)
│   └── Format: "instance_token_sample_token"
└── expansion/ (map polygons)
    ├── boston-seaport.json
    ├── singapore-hollandvillage.json
    ├── singapore-onenorth.json
    └── singapore-queenstown.json
```

## Key Differences

| Aspect | nuScenes Mini | Prediction Data |
|--------|--------------|-----------------|
| **Scenes** | 10 scenes | 833 scenes |
| **Format** | Separate JSON files | Combined token pairs |
| **Map Data** | Basic map references | Expanded polygon data |
| **Purpose** | General dataset | Trajectory prediction |

## Usage

The prediction data is designed for:
- **Trajectory prediction tasks**: Predicting future paths of objects
- **Multi-modal prediction**: Using both instance and sample information
- **Map-aware prediction**: Leveraging expanded map polygon data

## Token Format

Each entry in `prediction_scenes.json` follows this pattern:
```
{instance_token}_{sample_token}
```

Where:
- `instance_token`: Unique identifier for an object instance (vehicle, pedestrian, etc.)
- `sample_token`: Unique identifier for a specific timestamp/sample in a scene

This format allows linking:
- Object instances across time
- Sample timestamps to specific instances
- Scene context for prediction tasks

