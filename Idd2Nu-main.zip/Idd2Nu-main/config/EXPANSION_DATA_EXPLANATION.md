# Map Expansion Data Generation

## Overview

The expansion data files contain **detailed polygon geometry** that expands upon the base map data in nuScenes mini. These files provide comprehensive spatial information for trajectory prediction tasks by converting map images into structured polygon representations.

## Data Structure

### Expansion Files Location
`nu_scene/expansion/`

### Files by Location
- `boston-seaport.json` - 6,504 polygons
- `singapore-hollandvillage.json` - 2,739 polygons  
- `singapore-onenorth.json` - 4,886 polygons
- `singapore-queenstown.json` - 3,570 polygons

**Total: 17,699 polygons** across all locations

### File Structure
```json
{
  "version": "1.3",
  "polygon": [
    {
      "token": "unique-polygon-identifier",
      "exterior_node_tokens": [
        "node-token-1",
        "node-token-2",
        "node-token-3",
        ...
      ],
      "holes": []
    },
    ...
  ]
}
```

## How Expansion Data is Generated

### 1. **Base Map Data (nuScenes Mini)**

The base `v1.0-mini/map.json` contains:
- **4 map entries** (semantic_prior category)
- References to map image files (PNG format)
- Log tokens linking maps to specific driving logs
- **No polygon geometry** - only image references

**Example from base map:**
```json
{
  "category": "semantic_prior",
  "token": "53992ee3023e5494b90c316c183be829",
  "filename": "maps/53992ee3023e5494b90c316c183be829.png",
  "log_tokens": ["7e25a2c8ea1f41c5b0da1e69ecfa71a2", ...]
}
```

### 2. **Expansion Process**

The expansion data is created through a **map processing pipeline**:

#### Step 1: Map Image Processing
- Extract map images referenced in `map.json`
- Process semantic prior maps (road networks, lanes, intersections)
- Convert raster images to vector representations

#### Step 2: Polygon Extraction
- **Segmentation**: Identify distinct regions in map images
- **Contour Detection**: Extract boundaries of map features
- **Node Generation**: Create exterior node tokens for polygon vertices

#### Step 3: Polygon Structuring
- **Exterior Nodes**: Define the outer boundary of each polygon
  - Each polygon has a variable number of nodes (ranging from 4 to 7,748+)
  - Nodes are ordered to form closed polygons
- **Holes**: Some polygons contain interior holes (23 in boston-seaport, 1-5 in others)
- **Token Assignment**: Generate unique tokens for each polygon and node

#### Step 4: Location-Based Organization
- Group polygons by geographic location
- Match to log locations from `log.json`:
  - `boston-seaport` → Multiple driving logs
  - `singapore-onenorth` → n015-2018-07-24-11-22-45+0800
  - `singapore-queenstown` → Multiple driving logs
  - `singapore-hollandvillage` → n015-2018-11-21-19-38-26+0800

### 3. **Polygon Characteristics**

**Size Distribution:**
- **Small polygons**: 4-13 nodes (simple features)
- **Medium polygons**: 50-500 nodes (complex road segments)
- **Large polygons**: 500-1,600 nodes (major intersections)
- **Very large polygons**: 1,600-7,748 nodes (extensive road networks)

**Examples:**
- Boston-seaport: Polygons range from 6 to 1,594 nodes
- Singapore-onenorth: Largest polygon has 3,284 nodes
- Singapore-queenstown: Largest polygon has 7,748 nodes

**Holes:**
- Most polygons have no holes (`"holes": []`)
- Some complex polygons contain interior holes (e.g., donut-shaped regions)
- Boston-seaport: 23 polygons with holes
- Other locations: 1-5 polygons with holes

## Comparison: Base vs. Expansion

| Aspect | Base Map (map.json) | Expansion Files |
|--------|-------------------|-----------------|
| **Format** | Image references | Polygon geometry |
| **Entries** | 4 map images | 17,699 polygons |
| **Data Type** | Raster (PNG) | Vector (polygons) |
| **Detail Level** | Low (image files) | High (structured geometry) |
| **Use Case** | Visualization | Spatial queries, prediction |

## Generation Pipeline

```
nuScenes Map Images (PNG)
    ↓
Image Processing & Segmentation
    ↓
Contour Detection & Boundary Extraction
    ↓
Node Generation & Token Assignment
    ↓
Polygon Structuring (exterior nodes + holes)
    ↓
Location-Based Grouping
    ↓
Expansion JSON Files (by location)
```

## Key Features

### 1. **Spatial Representation**
- Converts 2D map images into structured polygon data
- Enables geometric queries (point-in-polygon, intersections)
- Supports trajectory prediction with map context

### 2. **Scalability**
- Handles large road networks (thousands of polygons per location)
- Efficient storage using token references
- Supports complex geometries (holes, multi-part polygons)

### 3. **Versioning**
- All expansion files use version "1.3"
- Consistent format across all locations
- Compatible with nuScenes prediction framework

## Usage in Prediction

The expansion data enables:

1. **Map-Aware Prediction**: Models can query which road segment a vehicle is on
2. **Trajectory Constraints**: Predictions respect road geometry and boundaries
3. **Spatial Reasoning**: Understand relationships between objects and map features
4. **Context-Aware Forecasting**: Use map topology for more accurate predictions

## Technical Details

### Node Tokens
- Format: UUID-style tokens (e.g., `"ee85f1a6-38c4-4491-8a3b-93e1d5bf2911"`)
- Each node represents a vertex in the polygon
- Nodes are ordered to form closed loops

### Polygon Tokens
- Unique identifier for each polygon
- Format: UUID-style (e.g., `"1b161e64-fe37-4f3f-96db-299edefe9f8c"`)
- Links to exterior nodes and holes

### Coordinate System
- Nodes reference spatial coordinates (not stored in expansion files)
- Coordinates are typically in the nuScenes coordinate system
- Used with ego pose and sample annotation data for spatial alignment

## Relationship to Prediction Data

The expansion data complements `prediction_scenes.json`:

- **Prediction scenes**: Instance-sample pairs for trajectory data
- **Expansion data**: Map polygons for spatial context
- **Combined**: Enables map-aware trajectory prediction

Together, they provide:
- **What happened**: Instance trajectories (prediction scenes)
- **Where it happened**: Map geometry (expansion data)
- **Context**: Spatial relationships for better predictions

