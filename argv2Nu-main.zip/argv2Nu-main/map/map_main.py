import argparse
from pathlib import Path
from typing import Dict, Any
from .expension import MapExpansionGenerator
from .prediction import PredictionSceneGenerator

def parse_args():
    parser = argparse.ArgumentParser(description="Generate map expansion and prediction data for ArgoV2")
    parser.add_argument("--map_dir", type=str, required=True, 
                       help="Directory containing ArgoV2 map data")
    parser.add_argument("--output_dir", type=str, default="output",
                       help="Output directory for generated files")
    parser.add_argument("--num_scenes", type=int, default=5,
                       help="Number of scenes to generate")
    return parser.parse_args()

def main():
    args = parse_args()
    map_dir = Path(args.map_dir)
    output_dir = Path(args.output_dir)
    
    # Create output directories
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all map files
    map_files = list(map_dir.glob("log_map_archive_*.json"))
    if not map_files:
        print("❌ No map files found in the specified directory")
        return
    
    # Process each map file
    for map_file in map_files:
        print(f"\nProcessing map file: {map_file.name}")
        
        # 1. Generate expansion data
        print("\nGenerating expansion data...")
        expansion_gen = MapExpansionGenerator(map_file)
        expansion_data = expansion_gen.generate_expansion_data()
        expansion_output = output_dir / f"expansion_{map_file.stem}.json"
        expansion_gen.save_expansion_data(expansion_output)
        
        # 2. Generate prediction scenes
        print("\nGenerating prediction scenes...")
        pred_gen = PredictionSceneGenerator(num_scenes=args.num_scenes)
        pred_gen.generate_scenes(expansion_data)
        
        # Save outputs
        pred_output = output_dir / "prediction_scenes.json"
        token_map_output = output_dir / "token_map.json"
        pred_gen.save_prediction_scenes(pred_output)
        pred_gen.save_token_map(token_map_output)
        
        print(f"\n✅ Successfully processed {map_file.name}")

if __name__ == "__main__":
    main()