import json
from pathlib import Path
from typing import Dict, List, Any
import uuid

class PredictionSceneGenerator:
    def __init__(self, num_scenes: int = 5):
        self.num_scenes = num_scenes
        self.scene_data: Dict[str, List[str]] = {}
        self.token_map: Dict[str, str] = {}
        
    def generate_scenes(self, expansion_data: Dict[str, Any]) -> None:
        """Generate prediction scenes with expansion data"""
        for scene_num in range(1, self.num_scenes + 1):
            scene_name = f"argov2_{scene_num}"
            self.scene_data[scene_name] = self._generate_scene_tokens(expansion_data)
    
    def _generate_scene_tokens(self, expansion_data: Dict[str, Any]) -> List[str]:
        """Generate tokens for all elements in a scene"""
        tokens = []
        
        # Add map tokens
        tokens.extend(self._get_or_create_tokens(expansion_data.get("pedestrian_crossings", {}).keys(), "crosswalk"))
        tokens.extend(self._get_or_create_tokens(expansion_data.get("driveable_areas", {}).keys(), "driveable"))
        tokens.extend(self._get_or_create_tokens(expansion_data.get("walkways", {}).keys(), "walkway"))
        
        return tokens
    
    def _get_or_create_tokens(self, elements: Any, prefix: str) -> List[str]:
        """Get or create tokens for map elements"""
        tokens = []
        for elem_id in elements:
            token_key = f"{prefix}_{elem_id}"
            if token_key not in self.token_map:
                self.token_map[token_key] = str(uuid.uuid4())
            tokens.append(self.token_map[token_key])
        return tokens
    
    def save_prediction_scenes(self, output_path: Path) -> None:
        """Save prediction scenes to JSON file"""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(self.scene_data, f, indent=2)
        print(f"✅ Prediction scenes saved to: {output_path}")
    
    def save_token_map(self, output_path: Path) -> None:
        """Save token mapping to JSON file"""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(self.token_map, f, indent=2)
        print(f"✅ Token map saved to: {output_path}")